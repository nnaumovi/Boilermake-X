using UnityEngine;
using System;
using System.Collections.Generic;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField] private float playerSpeed = 5.0f;
    [SerializeField] private float maxColloidGap = 0.5f;
    [SerializeField] private GameObject spriteQuad;

    [SerializeField] private Material rightStillTexture;
    [SerializeField] private Material right1Texture;
    [SerializeField] private Material right2Texture;

    [SerializeField] private Material leftStillTexture;
    [SerializeField] private Material left1Texture;
    [SerializeField] private Material left2Texture;

    [SerializeField] private Material upStillTexture;
    [SerializeField] private Material up1Texture;
    [SerializeField] private Material up2Texture;

    [SerializeField] private Material downStillTexture;
    [SerializeField] private Material down1Texture;
    [SerializeField] private Material down2Texture;

    [SerializeField] private Material invisibleMaterial;
    [SerializeField] private GameObject headQuad;


    private Rigidbody _playerRigidbody;

    private int spriteChangeTimer = 0;
    private int movementStage = 0;
    private int spriteChangeCD = 20;

    public GameObject closestItem;
    public int closestItemType; //0 = InventoryItem, 1 = HeadItem, 2 = Item Stand, Crop Land = 3
    public GameObject headItem;
    private bool headEmpty;

    public List<int> inventory = new List<int>(){8}; //Stores item IDs. 0 item ID means empty slot


    private void Start()
    {   
        headEmpty = true;
        _playerRigidbody = GetComponent<Rigidbody>();
        for (int i = 0; i < inventory.length; i++) {
            inventory[i] = 0;
        }
    }

    private void Update()
    {   
        MovePlayer();
        if(Input.GetButton("Jump")) {
            Debug.Log("Interact");
            if (closestItem!=null) {
                interact();
            }
            
        }
        
        
    }

    void interact() {
        
        float val = closestItem.transform.position.x - transform.position.x;
        if (!(val < maxColloidGap && val > -maxColloidGap)) {
            return;
        }

        val = closestItem.transform.position.z - transform.position.z;
        if (!(val < maxColloidGap && val > -maxColloidGap)) {
            return;
        }
        Debug.Log("In range of item");
        
        if (closestItemType == 0) {
            for (int i = 0; i < inventory.size(); i++) {
                if (inventory[i] == 0) {
                    closestItem.transform.position =  new Vector3(closestItem.transform.position.x, closestItem.transform.position.y, GameObject.FindGameObjectWithTag("Left Wall").transform.position.z+20);         
                    inventory[i] = closestItem.GetComponent<ItemScript>().itemId;
                }
            }
            
        } else if (closestItemType == 1 && headEmpty) {
           headQuad.GetComponent<MeshRenderer> ().material = closestItem.GetComponent<MeshRenderer> ().material;
           headItem = closestItem;
           headEmpty = false;
           closestItem.tag = "Item Stand";
           closestItem.GetComponent<MeshRenderer> ().material=invisibleMaterial;
        } else if (closestItemType == 2 && !headEmpty) {
            headEmpty = true;
            closestItem.GetComponent<MeshRenderer> ().material=headQuad.GetComponent<MeshRenderer> ().material;
            closestItem.tag = "HeadItem";
            headQuad.GetComponent<MeshRenderer> ().material = invisibleMaterial;
        }
    }


    private void MovePlayer() {
        var horizontalInput = Input.GetAxisRaw("Horizontal");
        var verticalInput = Input.GetAxisRaw("Vertical");

    
        changeSprite( horizontalInput,  verticalInput);
        
        _playerRigidbody.velocity = new Vector3(horizontalInput * playerSpeed, _playerRigidbody.velocity.y, verticalInput * playerSpeed);

    }

    void changeSprite(float horizontalInput, float verticalInput) {
        if (spriteChangeTimer > 0) {
            spriteChangeTimer--;
        } else {
            movementStage = ++movementStage%3;




            if (verticalInput > 0) {    
                spriteChangeTimer = spriteChangeCD;
                switch (movementStage){
                    case 0:
                        spriteQuad.GetComponent<MeshRenderer> ().material = up1Texture;
                        break;
                    case 1:
                        spriteQuad.GetComponent<MeshRenderer> ().material = upStillTexture;
                        break;
                    case 2:
                        spriteQuad.GetComponent<MeshRenderer> ().material = up2Texture;
                        break;
                }       
            }

            if (verticalInput < 0) {    
                spriteChangeTimer = spriteChangeCD;
                switch (movementStage){
                    case 0:
                        spriteQuad.GetComponent<MeshRenderer> ().material = down1Texture;
                        break;
                    case 1:
                        spriteQuad.GetComponent<MeshRenderer> ().material = downStillTexture;
                        break;
                    case 2:
                        spriteQuad.GetComponent<MeshRenderer> ().material = down2Texture;
                        break;
                }       
            }





            if (horizontalInput > 0) {    
                spriteChangeTimer = spriteChangeCD;
                switch (movementStage){
                    case 0:
                        spriteQuad.GetComponent<MeshRenderer> ().material = right1Texture;
                        break;
                    case 1:
                        spriteQuad.GetComponent<MeshRenderer> ().material = rightStillTexture;
                        break;
                    case 2:
                        spriteQuad.GetComponent<MeshRenderer> ().material = right2Texture;
                        break;
                }       
            }

            if (horizontalInput < 0) {    
                spriteChangeTimer = spriteChangeCD;
                switch (movementStage){
                    case 0:
                        spriteQuad.GetComponent<MeshRenderer> ().material = left1Texture;
                        break;
                    case 1:
                        spriteQuad.GetComponent<MeshRenderer> ().material = leftStillTexture;
                        break;
                    case 2:
                        spriteQuad.GetComponent<MeshRenderer> ().material = left2Texture;
                        break;
                }       
            }

            


             
        }




    }

    

/*
    void OnTriggerEnter(Collider col)
    {
        
        if (col.gameObject.tag == "HeadItem" || col.gameObject.tag == "InventoryItem"){
            closestItem = col.gameObject;    
            Debug.Log("Item");
            if (col.gameObject.tag == "HeadItem") {
                Debug.Log("headItem");
                closestItemIsHeadItem = true;
            } else {
                closestItemIsHeadItem = false;
            }
        }
        
    }
    */

   
}