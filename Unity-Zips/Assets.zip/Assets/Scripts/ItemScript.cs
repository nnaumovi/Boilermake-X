using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemScript : MonoBehaviour
{
    private PlayerMovement playerSc;
    public int cropId;
    public int cropGrowthTime;


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter(Collider col)
    {
        if (col.gameObject.tag != "Player") {
            return;
        }
        playerSc = col.gameObject.GetComponent<PlayerMovement>();

        playerSc.closestItem = gameObject.transform.parent.gameObject;    
        Debug.Log("Item");
        if (playerSc.closestItem.tag == "HeadItem") {
            Debug.Log("HeadItem");
            playerSc.closestItemType = 1;
        } else if (playerSc.closestItem.tag == "Item Stand") {
            Debug.Log("Item Stand");
            playerSc.closestItemType = 2;
        } else if (playerSc.closestItem.tag == "CropLand") {
            Debug.Log("CropLand");
            playerSc.closestItemType = 3;
        } else if (playerSc.closestItem.tag == "SceneChanger") {
            Debug.Log("SceneChanger");
            playerSc.closestItemType = 4;
        } else {
            Debug.Log("InventoryItem");
            playerSc.closestItemType = 0;
        }
    
        
    }
}
