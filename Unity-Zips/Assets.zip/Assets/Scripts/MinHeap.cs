
using System;
using System.Globalization;
using System.Collections.Generic;

public class timerHeap {
    List<DateTime> spoilTimes = new List<DateTime>(){};

    private bool timePassed(){
        
        if (peekTime().CompareTo(DateTime.Now) < 0) {
                // food has spoiled/cooked
                DateTime spoilFood = popTime();
                return true;
        }
        return false;
                
    }
    public void pushTime(DateTime t) {
        
        for (int i = 0; i < spoilTimes.Count; i++) {
            if (spoilTimes[i].CompareTo(t) > 0) {
                // t is earlier than spoilTime[i]
                spoilTimes.Insert(i, t);
                return;
            }
        }
        
        spoilTimes.Add(t);
        return;
    }
    
    
    public DateTime peekTime() {
        return spoilTimes[0];
    }
    
    
    public DateTime popTime() {
        DateTime earliestTime = spoilTimes[0];
        spoilTimes.RemoveAt(0);
        return earliestTime;
    }
    
}